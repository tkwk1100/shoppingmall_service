package com.shopping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoppingmallServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShoppingmallServiceApplication.class, args);
	}

}
