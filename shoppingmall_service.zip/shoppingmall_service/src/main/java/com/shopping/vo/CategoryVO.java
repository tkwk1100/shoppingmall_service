package com.shopping.vo;

import lombok.Data;

@Data
public class CategoryVO {
    private Integer cate_seq;
    private String cate_name;
}
