package com.shopping.vo;

import lombok.Data;
// 데이터 전송 전용.
@Data
public class LoginVO {
    private String id;
    private String pwd;
}
