package com.shopping.vo;

import lombok.Data;

@Data
public class ShoppingCartVO {
    private Integer sc_mi_seq;
    private Integer sc_pi_seq;
    private Integer sc_count;
}
